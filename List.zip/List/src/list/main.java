package list;

public class main {

	public static void main(String[] args) throws Exception {
		
		list l = new list(8);
		
		System.out.println(l.isEmpty());
		
		l.mostrar();
		System.out.println("Insert");
		l.insert(0,1);
		l.insert(1,2);
		l.insert(2,3);
		l.insert(3,4);
		l.mostrar();
		
		System.out.println("set");
		l.set(0, 7);
		l.mostrar();
		
		System.out.println("get");
		System.out.println(l.get(2));
		
		System.out.println("size");
		System.out.println(l.size());
		
		System.out.println("remove");
		l.remove(3);
		l.mostrar();
		
		System.out.println(l.isEmpty());
		
	}

}
