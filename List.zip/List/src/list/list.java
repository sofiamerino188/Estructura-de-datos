package list;

public class list {
	
	int[] lista;
	int size;
	int log;
	
	public list(int n){
		lista = new int[n];
		size=0;
		log=n;
	}
	
	public void set(int pos,int n) throws Exception{
		if(pos>log){
			throw new Exception("Error set");
		}else{
			lista[pos]=n;
		}
		
	}
	
	public int get(int pos) throws Exception{
		if(isEmpty() || pos>log){
			throw new Exception("Error get");
		}else{
			return lista[pos];
		}
	}
	
	public int size(){
		return size;
	}
	
	public void remove(int pos) throws Exception{
		if(isEmpty() || pos>log){
			throw new Exception("Error remove");
		}else{
			for(int i=pos;i<size;i++){
				lista[i]=lista[i+1];
			}
			size--;
		}
	}
	
	public void insert(int pos,int n) throws Exception{
		if(pos>log || size==log){
			throw new Exception("Error insert");
		}else{
			for(int i=size;i>pos;i++){
				lista[i]=lista[i-1];
			}
			lista[pos]=n;
			size++;
		}
	}
	
	public void mostrar(){
		for(int i=0;i<size;i++){
			System.out.print(lista[i]+" ");
		}
		System.out.println("");
	}
	
	public boolean isEmpty(){
		if(size==0){
			return true;
		}else{
			return false;
		}
	}
}
