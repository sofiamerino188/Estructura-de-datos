package Cola;

public class Main {

	public static void main(String[] args) throws Exception {
		
		Queue cola = new Queue(4);
		
		System.out.println("Probamos IsEmpty");
		System.out.println(cola.isEmpty());
		
		System.out.println("Probamos enqueue");
		cola.enqueue(1);
		cola.enqueue(5);
		cola.enqueue(6);
		cola.mostrar();
		
		System.out.println("Probamos First");
		System.out.println(cola.First());
		
		System.out.println("Probamos IsEmpty");
		System.out.println(cola.isEmpty());
		
		System.out.println("Probamos dequeue");
		cola.dequeue();
		cola.mostrar();
		
		System.out.println("Probamos First");
		System.out.println(cola.First());
		
		cola.dequeue();
		cola.mostrar();
		cola.dequeue();
		cola.mostrar();
		
		
	}

}
