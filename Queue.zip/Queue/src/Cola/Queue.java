package Cola;

public class Queue {
	
	int primero;
	int ultimo;
	int []cola;
	int log;
	
	public Queue(int n){
		primero=-1;
		ultimo=-1;
		log=n;
		cola = new int[n];
	}
	
	public void enqueue(int elem) throws Exception{
		if(isEmpty()){
			primero=0;
			cola[primero]=elem;
			ultimo=0;
		}else if(ultimo<log){
			ultimo++;
			cola[ultimo]=elem;
		}else{
			throw new Exception("Error enqueue,cola llena");
		}
	}
	
	public void dequeue() throws Exception{
		if(isEmpty()){
			throw new Exception("Error dequeue,cola vacia");
		}else{
			for(int i=0;i<ultimo;i++){
				cola[i]=cola[i+1];
			}
			ultimo--;
			if(ultimo==-1){
				primero=-1;
			}
		}
	}
	
	public int First() throws Exception{
		if(!isEmpty()){
			return cola[primero];
		}else{
			throw new Exception("Error Frist,lista vacia");
		}
	}
	
	public Boolean isEmpty(){
		if(primero<0){
			return true;
		}else{
			return false;
		}
		
	}
	
	public void mostrar(){
		if(isEmpty()){
			System.out.println("Lista vacia");
		}else{
			for(int i=0;i<=ultimo;i++){
				System.out.print(cola[i]+" ");
			}
			System.out.println("");
		}
		
		
	}
}
