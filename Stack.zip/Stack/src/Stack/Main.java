package Stack;

public class Main {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		int num = 8;
		Stack pila = new Stack(num);
		boolean vacio;
		
		System.out.println("Probamos IsEmpty");
		vacio = pila.IsEmpty();
		System.out.println(vacio);
		
		pila.push(5);
		pila.push(4);
		
		System.out.println("Probamos el top");
		System.out.println(pila.top());
		
		pila.push(6);
		pila.push(2);
		pila.push(1);
		
		System.out.println("Probamos el top");
		System.out.println(pila.top());
		
		
		System.out.println("Probamos el push");
		for(int i=0;i<pila.pos();i++){
			System.out.println(pila.elem(i)+" ");
		}
		
		System.out.println("Probamos IsEmpty");
		vacio = pila.IsEmpty();
		System.out.println(vacio);
		
		pila.pop();
		pila.pop();
		
		System.out.println("Probamos el pop");
		for(int i=0;i<pila.pos();i++){
			System.out.println(pila.elem(i)+" ");
		}
		
		pila.pop();
		pila.pop();
		pila.pop();
		
		System.out.println("Probamos IsEmpty");
		vacio = pila.IsEmpty();
		System.out.println(vacio);
		
		
	}

}
