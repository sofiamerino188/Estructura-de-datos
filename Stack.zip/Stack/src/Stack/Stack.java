package Stack;

public class Stack {
	
	int [] pila;
	int pos;
	int log;
	
	public Stack(int num){
		pila = new int[num];
		pos=0;
		log=num;
	}
	
	public Boolean IsEmpty(){
		Boolean vacio=false;
		
		if(pos<=0){
			vacio=true;
		}
		
		return vacio;
	}
	
	public void push(int elem) throws Exception{
		if(pos<log){
		pila[pos]=elem;
		pos++;
		}else{
			throw new Exception("Error push,lista llena");
		}
	}
	
	public void pop() throws Exception{
		if(!IsEmpty()){
			pila[pos]=0;
			pos --;
		}else{
			throw new Exception("Error pop,lista vacia");
		}
	}
	
	public int top() throws Exception{
		if(IsEmpty()){
			throw new Exception("Error top,lista vacia");
		}else{
			return pila[pos-1];
		}
	}
	
	public int pos(){
		return pos;
	}
	
	public int elem(int n){
		return pila[n];
	}
}
