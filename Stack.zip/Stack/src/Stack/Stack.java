package Stack;

public class Stack {
	
	int [] pila;
	int pos;
	
	public Stack(int num){
		pila = new int[num];
		pos=0;
	}
	
	public Boolean IsEmpty(){
		Boolean vacio=false;
		
		if(pos==0){
			vacio=true;
		}
		
		return vacio;
	}
	
	public void push(int elem){
		
		pila[pos]=elem;
		pos++;
	}
	
	public void pop(){
		if(!IsEmpty()){
			pila[pos]=0;
			pos --;
		}
	}
	
	public int top(){
		if(IsEmpty()){
			return -1;
		}else{
			return pila[pos-1];
		}
	}
	
	public int pos(){
		return pos;
	}
	
	public int elem(int n){
		return pila[n];
	}
}
