package set;

public class main {

	public static void main(String[] args) throws Exception {
		
		set s = new set(8);
		
		System.out.println(s.isEmpty());
		s.mostrar();
		
		s.insert(1);
		s.insert(3);
		s.insert(4);
		s.insert(5);
		s.insert(1);
		s.mostrar();
		
		System.out.println(s.isEmpty());
		
		System.out.println(s.isElem(4));
		System.out.println(s.isElem(10));
		
		s.delete(4);
		s.delete(10);
		s.mostrar();
	}

}
