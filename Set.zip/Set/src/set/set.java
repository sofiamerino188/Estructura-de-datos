package set;

public class set {
	
	int[] set;
	int log;
	int tam;
	
	public set(int n){
		set= new int[n];
		log=n;
		tam=0;
	}
	
	public boolean isEmpty(){
		if(tam<=0){
			return true;
		}else{
			return false;
		}
	}
	
	public void insert(int n) throws Exception{
		boolean esta=false;
		if(tam==log){
			throw new Exception("Error insert");
		}else{
			if(!isElem(n)){
				set[tam]=n;
				tam++;
			}
		}
	}
	
	private int pos(int n){
		int pos=-1;
		for(int i=0;i<tam;i++){
			if(set[i]==n){
				pos=i;
			}
		}
		return pos;
	}
	
	public void delete(int n) throws Exception{
		if(isEmpty()){
			throw new Exception("Error delete");
		}else{
			if(isElem(n)){
				int pos = pos(n);
				if(pos!=-1){
					for(int i=pos;i<tam;i++){
						set[i]=set[i+1];
					}
				}
				tam--;
			}
		}
	}
	
	public boolean isElem(int n) throws Exception{
		boolean esta=false; 
		for(int i=0;i<tam;i++){
			if(set[i]==n){
				esta=true;
			}
		}
		return esta;
	}
	
	public void mostrar(){
		for(int i=0;i<tam;i++){
			System.out.print(set[i]+" ");
		}
		System.out.println("");
	}
}
